import { defineComponentDesign } from "../../_design/define-design";
import { DocumentSurface } from "./surface";
export default defineComponentDesign(DocumentSurface, {
  defaults: { uri: "https://example.test/reader.html", title: "Dokument", onReady: () => {}, onError: (_message: string) => {} },
  designs: { default: {} }, render: props => <DocumentSurface {...props} />,
});
