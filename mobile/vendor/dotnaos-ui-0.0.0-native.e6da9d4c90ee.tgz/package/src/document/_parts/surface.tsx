import { WebView } from "react-native-webview";
import { allowDocumentNavigation } from "../navigation";
import type { SurfaceProps } from "./types";

export function DocumentSurface({ uri, title, onReady, onError }: SurfaceProps) {
  return <WebView
    source={{ uri }}
    style={{ flex: 1, backgroundColor: "transparent" }}
    accessibilityLabel={title}
    // Handle every navigation ourselves; a restrictive originWhitelist delegates
    // denied links to the OS and would open Safari instead of blocking them.
    originWhitelist={["*"]}
    onShouldStartLoadWithRequest={({ url }) => allowDocumentNavigation(uri, url)}
    onOpenWindow={() => onError("Externe Navigation ist in dieser Dokumentansicht deaktiviert.")}
    onFileDownload={() => onError("Diese Datei kann hier nicht direkt angezeigt werden.")}
    onLoad={onReady}
    onError={() => onError("Das Dokument konnte nicht geladen werden. Prüfe die Verbindung und versuche es erneut.")}
    onHttpError={({ nativeEvent }) => onError(`Die Dokumentansicht ist nicht erreichbar (${nativeEvent.statusCode}).`)}
    onContentProcessDidTerminate={() => onError("Die Dokumentansicht wurde beendet. Bitte erneut laden.")}
    javaScriptCanOpenWindowsAutomatically={false}
    setSupportMultipleWindows={true}
    allowFileAccess={false}
    allowFileAccessFromFileURLs={false}
    allowUniversalAccessFromFileURLs={false}
    mixedContentMode="never"
    sharedCookiesEnabled={false}
    thirdPartyCookiesEnabled={false}
    automaticallyAdjustContentInsets={false}
    contentInsetAdjustmentBehavior="never"
    allowsBackForwardNavigationGestures={false}
  />;
}
