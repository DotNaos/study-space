export interface SurfaceProps {
  uri: string;
  title: string;
  onReady: () => void;
  onError: (message: string) => void;
}
