import type { SurfaceProps } from "./types";

export function DocumentSurface({ uri, title, onReady, onError }: SurfaceProps) {
  return <iframe src={uri} title={title} onLoad={onReady}
    onError={() => onError("Die Dokumentansicht konnte nicht geladen werden.")}
    referrerPolicy="no-referrer" sandbox="allow-scripts allow-same-origin"
    style={{ width: "100%", height: "100%", flex: 1, border: 0, minHeight: 0 }} />;
}
