import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, View } from "react-native";
import { Button } from "../components/Button";
import { Text } from "../components/Text";
import { Stack } from "../components/Stack";
import { useNativeTheme } from "../theme";
import { DocumentSurface } from "./_parts/surface";
import { documentUrl } from "./navigation";

export interface ViewerProps {
  /** URL of an application-owned HTML reader, not a third-party document service. */
  uri: string;
  title: string;
}

export function Viewer({ uri, title }: ViewerProps) {
  const { colors } = useNativeTheme();
  const [attempt, setAttempt] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const source = documentUrl(uri);
  const ready = useCallback(() => { clearTimeout(timer.current); setLoading(false); }, []);
  const fail = useCallback((message: string) => { clearTimeout(timer.current); setLoading(false); setError(message); }, []);
  useEffect(() => {
    setLoading(true); setError("");
    timer.current = setTimeout(() => fail("Die Dokumentansicht antwortet nicht. Bitte erneut laden."), 30000);
    return () => clearTimeout(timer.current);
  }, [uri, attempt, fail]);
  return <View style={{ flex: 1, minHeight: 0, backgroundColor: colors.background }}>
    {!source || error ? <Stack gap={3} style={{ margin: 20 }}>
      <Text selectable text={!source ? "Ungültige Dokumentadresse." : error} />
      {source ? <Button label="Erneut versuchen" variant="secondary" onPress={() => setAttempt(value => value + 1)} /> : null}
    </Stack> : <DocumentSurface key={`${source}:${attempt}`} uri={source} title={title} onReady={ready} onError={fail} />}
    {source && !error && loading ? <View pointerEvents="none" style={{ position: "absolute", inset: 0, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
      <ActivityIndicator accessibilityLabel="Dokument wird geladen" color={colors.textMuted} />
    </View> : null}
  </View>;
}
