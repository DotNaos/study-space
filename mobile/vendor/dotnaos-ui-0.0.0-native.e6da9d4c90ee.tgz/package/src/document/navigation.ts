export function documentUrl(uri: string): string | undefined {
  try {
    const url = new URL(uri);
    if (url.username || url.password) return undefined;
    if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))) return undefined;
    return url.href;
  } catch { return undefined; }
}

export function allowDocumentNavigation(uri: string, next: string): boolean {
  if (next === "about:blank") return true;
  const initial = documentUrl(uri);
  const target = documentUrl(next);
  if (!initial || !target) return false;
  const source = new URL(initial);
  const destination = new URL(target);
  return source.origin === destination.origin && source.pathname === destination.pathname && source.search === destination.search;
}
