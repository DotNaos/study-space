import { defineComponentDesign } from "../_design/define-design";
import { Viewer } from "./Viewer";
export default defineComponentDesign(Viewer, {
  defaults: { uri: "https://example.test/reader.html", title: "Dokument" },
  designs: { default: {}, invalid: { uri: "file:///not-allowed" } },
  render: props => <Viewer {...props} />,
});
