# DotNaos UI native preview

Source: DotNaos/ui commit e6da9d4c90eea105cb6c64332e45478bb1626d98, components/ui/native.

This is the actual shared native library, packaged without web-only components. Import from @dotnaos/ui/native. Its TypeScript source is compiled by Metro. Replace the archive dependency with a published complete @dotnaos/ui version once a release containing this commit is available.
