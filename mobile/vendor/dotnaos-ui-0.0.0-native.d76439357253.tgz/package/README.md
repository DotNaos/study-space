# DotNaos UI native preview

Source: DotNaos/ui commit d7643935725315fe445e90b3561773313fbb07db, components/ui/native.

This is the actual shared native library, packaged without web-only components. Import from @dotnaos/ui/native. Its TypeScript source is compiled by Metro. Replace the archive dependency with a published complete @dotnaos/ui version once a release containing this commit is available.
