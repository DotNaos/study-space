import type { NativeChatRole } from "./types";
import { designTokenThemes } from "@dotnaos/design";

export interface ChatNativeTheme {
  accent?: string;
  assistant?: string;
  background?: string;
  border?: string;
  danger?: string;
  muted?: string;
  panel?: string;
  soft?: string;
  text?: string;
  user?: string;
}

const dark = designTokenThemes.dark.colors;

export const defaultChatNativeTheme = {
  accent: dark.accent,
  assistant: dark.accent,
  background: dark.background,
  border: dark.border,
  danger: dark.danger,
  muted: dark.textMuted,
  panel: dark.surfaceMuted,
  soft: dark.surface,
  text: dark.text,
  user: dark.text,
} satisfies Required<ChatNativeTheme>;

export function resolveChatNativeTheme(theme?: ChatNativeTheme) {
  return { ...defaultChatNativeTheme, ...theme };
}

export function roleColor(role: NativeChatRole, theme?: ChatNativeTheme) {
  const colors = resolveChatNativeTheme(theme);

  if (role === "assistant") return colors.assistant;
  if (role === "user") return colors.user;
  if (role === "runtime" || role === "tool") return colors.accent;
  return colors.muted;
}

export function formatMessageTime(value?: Date | number | string) {
  if (!value) return "";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return typeof value === "string" ? value : "";
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
