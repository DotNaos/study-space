import { StyleSheet, Text, View } from "react-native";
import { ChatNativeMarkdownText } from "./MarkdownText";
import { formatMessageTime, resolveChatNativeTheme, roleColor, type ChatNativeTheme } from "./theme";
import type { NativeChatAttachment, NativeChatMessage, NativeChatRole } from "./types";

export interface ChatNativeMessageBubbleProps { message: NativeChatMessage; previousRole?: NativeChatRole; theme?: ChatNativeTheme; }

export function ChatNativeMessageBubble({ message, previousRole, theme }: ChatNativeMessageBubbleProps) {
  const colors = resolveChatNativeTheme(theme);
  const sameSource = previousRole === message.role;
  const accent = roleColor(message.role, theme);
  const isUser = message.role === "user";
  const label = message.label ?? message.toolName ?? message.role;
  const markdownText = [message.content, ...(message.blocks ?? []).map((block) => block.content)].filter(Boolean).join("\n\n");

  return (
    <View style={[styles.message, sameSource && styles.compact, isUser && [styles.userBubble, { backgroundColor: colors.panel, borderColor: colors.border }], !isUser && [styles.assistantBubble, { borderLeftColor: accent }]]}>
      {!sameSource && <View style={styles.topline}><View style={styles.roleGroup}><View style={[styles.roleDot, { backgroundColor: accent }]} /><Text style={[styles.role, { color: accent }]}>{label}</Text></View><Text style={[styles.time, { color: colors.muted }]}>{formatMessageTime(message.createdAt)}</Text></View>}
      {message.attachments?.length ? <AttachmentList attachments={message.attachments} theme={theme} /> : null}
      <ChatNativeMarkdownText style={[styles.text, { color: colors.text }, message.role !== "assistant" && { color: colors.muted }]} text={markdownText} theme={theme} />
    </View>
  );
}

function AttachmentList({ attachments, theme }: { attachments: readonly NativeChatAttachment[]; theme?: ChatNativeTheme }) {
  const colors = resolveChatNativeTheme(theme);
  return <View style={styles.attachments}>{attachments.map((attachment) => <View key={attachment.id ?? attachment.name} style={[styles.attachment, { backgroundColor: colors.soft }]}><Text numberOfLines={1} style={[styles.attachmentText, { color: colors.text }]}>{attachment.kind ? `${attachment.kind}: ${attachment.name}` : attachment.name}</Text></View>)}</View>;
}

const styles = StyleSheet.create({
  assistantBubble: { alignSelf: "stretch", borderLeftWidth: 2, paddingLeft: 12 },
  attachment: { borderRadius: 10, minHeight: 28, paddingHorizontal: 10, paddingVertical: 6 },
  attachmentText: { fontSize: 12, fontWeight: "600" }, attachments: { gap: 6, marginBottom: 8 },
  compact: { marginTop: -8 }, message: { paddingVertical: 2 },
  role: { fontSize: 10, fontWeight: "700", letterSpacing: 0.6, textTransform: "uppercase" },
  roleDot: { borderRadius: 4, height: 7, width: 7 }, roleGroup: { alignItems: "center", flexDirection: "row", gap: 7 },
  text: { fontSize: 15, lineHeight: 21 }, time: { fontSize: 10 },
  topline: { alignItems: "center", flexDirection: "row", justifyContent: "space-between", marginBottom: 4 },
  userBubble: { alignSelf: "flex-end", borderRadius: 20, borderWidth: StyleSheet.hairlineWidth, maxWidth: "84%", paddingHorizontal: 14, paddingVertical: 10 },
});
