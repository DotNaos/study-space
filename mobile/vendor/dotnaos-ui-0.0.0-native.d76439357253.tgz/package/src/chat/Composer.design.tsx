import { defineComponentDesign } from "../_design/define-design";
import { ChatNativeComposer } from "./Composer";
import { nativeChatActions, nativeChatSuggestions, noopInputChange, noopSubmit } from "./_design/fixtures";

export default defineComponentDesign(ChatNativeComposer, {
  defaults: { inputValue: "Review the mobile layout", modelLabel: "Standard", modelOptions: nativeChatActions, onInputChange: noopInputChange, onSubmit: noopSubmit, suggestions: nativeChatSuggestions },
  designs: { default: {}, disabled: { disabled: true }, streaming: { onStop: () => {}, state: "streaming" } },
  render: (props) => <ChatNativeComposer {...props} />,
});
