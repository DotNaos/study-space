import {
  ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View,
  type StyleProp, type TextStyle, type ViewStyle,
} from "react-native";
import { resolveChatNativeTheme, type ChatNativeTheme } from "./theme";
import type { NativeChatAction, NativeChatRunState, NativeChatSuggestion } from "./types";

export interface ChatNativeComposerProps {
  disabled?: boolean;
  inputStyle?: StyleProp<TextStyle>;
  inputValue: string;
  modelLabel?: string;
  modelOptions?: readonly NativeChatAction[];
  onAttachmentSelect?: () => void;
  onInputChange: (value: string) => void;
  onModelSelect?: (action: NativeChatAction) => void;
  onPermissionSelect?: (action: NativeChatAction) => void;
  onStop?: () => void;
  onSubmit: (value: string) => void;
  onSuggestionSelect?: (suggestion: NativeChatSuggestion) => void;
  permissionLabel?: string;
  permissionOptions?: readonly NativeChatAction[];
  placeholder?: string;
  state?: NativeChatRunState;
  stopLabel?: string;
  style?: StyleProp<ViewStyle>;
  submitLabel?: string;
  suggestions?: readonly NativeChatSuggestion[];
  theme?: ChatNativeTheme;
}

export function ChatNativeComposer({
  disabled = false, inputStyle, inputValue, modelLabel, modelOptions = [],
  onAttachmentSelect, onInputChange, onModelSelect, onPermissionSelect, onStop,
  onSubmit, onSuggestionSelect, permissionLabel, permissionOptions = [],
  placeholder = "Message", state = "idle", stopLabel = "Stop", style,
  submitLabel = "Send", suggestions = [], theme,
}: ChatNativeComposerProps) {
  const colors = resolveChatNativeTheme(theme);
  const busy = state === "streaming" || state === "waiting";
  const canSubmit = inputValue.trim().length > 0 && !disabled && !busy;

  return (
    <View style={[styles.box, { backgroundColor: colors.panel, borderColor: colors.border }, style]}>
      {suggestions.length > 0 && (
        <View style={styles.suggestions}>
          {suggestions.map((suggestion) => (
            <Pressable key={suggestion.id} onPress={() => onSuggestionSelect?.(suggestion)} style={[styles.suggestion, { borderColor: colors.border }]}>
              <Text style={[styles.suggestionText, { color: colors.muted }]}>{suggestion.label}</Text>
            </Pressable>
          ))}
        </View>
      )}
      <TextInput editable={!disabled && !busy} multiline onChangeText={onInputChange} placeholder={placeholder} placeholderTextColor={colors.muted} style={[styles.input, { color: colors.text }, inputStyle]} value={inputValue} />
      <View style={styles.footer}>
        <Pressable accessibilityLabel="Add attachment" onPress={onAttachmentSelect} style={styles.iconButton}>
          <Text style={[styles.iconText, { color: colors.text }]}>+</Text>
        </Pressable>
        {permissionLabel ? <ControlPill label={permissionLabel} onPress={() => permissionOptions[0] && onPermissionSelect?.(permissionOptions[0])} theme={theme} /> : null}
        {modelLabel ? <ControlPill label={modelLabel} onPress={() => modelOptions[0] && onModelSelect?.(modelOptions[0])} theme={theme} /> : null}
        {busy && onStop ? (
          <Pressable onPress={onStop} style={[styles.sendButton, { backgroundColor: colors.danger }]}>
            <Text style={[styles.sendText, { color: colors.text }]}>{stopLabel}</Text>
          </Pressable>
        ) : (
          <Pressable disabled={!canSubmit} onPress={() => canSubmit && onSubmit(inputValue.trim())} style={[styles.sendButton, { backgroundColor: colors.accent }, !canSubmit && styles.disabled]}>
            {busy ? <ActivityIndicator color={colors.text} /> : <Text style={[styles.sendText, { color: colors.text }]}>{submitLabel}</Text>}
          </Pressable>
        )}
      </View>
    </View>
  );
}

function ControlPill({ label, onPress, theme }: { label: string; onPress?: () => void; theme?: ChatNativeTheme }) {
  const colors = resolveChatNativeTheme(theme);
  return <Pressable onPress={onPress} style={[styles.pill, { backgroundColor: colors.soft }]}><Text numberOfLines={1} style={[styles.pillText, { color: colors.text }]}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  box: { borderRadius: 24, borderWidth: StyleSheet.hairlineWidth, gap: 10, paddingBottom: 10, paddingHorizontal: 10, paddingTop: 10 },
  disabled: { opacity: 0.55 },
  footer: { alignItems: "center", flexDirection: "row", gap: 8 },
  iconButton: { alignItems: "center", borderRadius: 18, height: 36, justifyContent: "center", width: 36 },
  iconText: { fontSize: 26, lineHeight: 30 },
  input: { fontSize: 16, lineHeight: 22, maxHeight: 150, minHeight: 82, paddingHorizontal: 10, paddingVertical: 8 },
  pill: { alignItems: "center", borderRadius: 18, flex: 1, minHeight: 36, justifyContent: "center", paddingHorizontal: 12 },
  pillText: { fontSize: 13, fontWeight: "700" },
  sendButton: { alignItems: "center", borderRadius: 18, minHeight: 38, justifyContent: "center", minWidth: 64, paddingHorizontal: 14 },
  sendText: { fontSize: 14, fontWeight: "800" },
  suggestion: { borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, minHeight: 36, justifyContent: "center", paddingHorizontal: 12 },
  suggestions: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  suggestionText: { fontSize: 13, fontWeight: "600" },
});
