import { defineComponentDesign } from "../_design/define-design";
import { ChatNativeMarkdownText } from "./MarkdownText";

export default defineComponentDesign(ChatNativeMarkdownText, {
  defaults: { text: "## Review\n\nUse **clear hierarchy** and `stable spacing`.\n\n- Compact navigation\n- Readable content" },
  designs: { default: {}, code: { text: "```tsx\n<View accessibilityLabel=\"Preview\" />\n```" }, plain: { text: "A short assistant response." } },
  render: (props) => <ChatNativeMarkdownText {...props} />,
});
