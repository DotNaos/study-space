import type { NativeChatAction, NativeChatMessage, NativeChatSuggestion } from "../types";

export const nativeChatActions: readonly NativeChatAction[] = [
  { id: "standard", label: "Standard" },
  { id: "fast", label: "Fast" },
];

export const nativeChatSuggestions: readonly NativeChatSuggestion[] = [
  { id: "summarize", label: "Summarize", prompt: "Summarize the current changes" },
  { id: "review", label: "Review", prompt: "Review the implementation" },
];

export const nativeChatMessages: readonly NativeChatMessage[] = [
  { id: "user", role: "user", content: "Can you review the mobile layout?", createdAt: "10:24" },
  { id: "assistant", role: "assistant", content: "## Review\n\nThe layout is ready.\n\n- Navigation is compact\n- Content remains readable", createdAt: "10:25" },
];

export const noopInputChange = (_value: string) => {};
export const noopSubmit = (_value: string) => {};
