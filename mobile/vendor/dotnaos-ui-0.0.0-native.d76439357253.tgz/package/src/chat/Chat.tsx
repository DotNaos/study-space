import { StyleSheet, Text, View, type StyleProp, type ViewStyle } from "react-native";
import { ChatNativeComposer } from "./Composer";
import { ChatNativeMessageList } from "./MessageList";
import { resolveChatNativeTheme, type ChatNativeTheme } from "./theme";
import type { NativeChatProps } from "./types";

export interface ChatNativeProps extends NativeChatProps {
  contentContainerStyle?: StyleProp<ViewStyle>;
  style?: StyleProp<ViewStyle>;
  theme?: ChatNativeTheme;
}

export function Chat({
  branchLabel, contentContainerStyle, description, disabled, inputValue, messages,
  modelLabel, modelOptions, onAttachmentSelect, onInputChange, onModelSelect,
  onPermissionSelect, onStop, onSubmit, onSuggestionSelect, permissionLabel,
  permissionOptions, placeholder, state = "idle", stopLabel, style, submitLabel,
  suggestions, theme, title,
}: ChatNativeProps) {
  const colors = resolveChatNativeTheme(theme);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }, style]}>
      {(title || description || branchLabel) && (
        <View style={styles.header}>
          {title ? <Text style={[styles.title, { color: colors.text }]}>{title}</Text> : null}
          {description ? <Text style={[styles.description, { color: colors.muted }]}>{description}</Text> : null}
          {branchLabel ? <Text style={[styles.branch, { color: colors.muted }]}>{branchLabel}</Text> : null}
        </View>
      )}
      <ChatNativeMessageList contentContainerStyle={contentContainerStyle} messages={messages} theme={theme} />
      <View style={styles.composerWrap}>
        <ChatNativeComposer
          disabled={disabled} inputValue={inputValue} modelLabel={modelLabel}
          modelOptions={modelOptions} onAttachmentSelect={onAttachmentSelect}
          onInputChange={onInputChange} onModelSelect={onModelSelect}
          onPermissionSelect={onPermissionSelect} onStop={onStop} onSubmit={onSubmit}
          onSuggestionSelect={onSuggestionSelect} permissionLabel={permissionLabel}
          permissionOptions={permissionOptions} placeholder={placeholder} state={state}
          stopLabel={stopLabel} submitLabel={submitLabel} suggestions={suggestions} theme={theme}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  branch: { fontSize: 12, fontWeight: "700" },
  composerWrap: { padding: 12 },
  description: { fontSize: 14, lineHeight: 20 },
  header: { gap: 6, paddingHorizontal: 18, paddingTop: 18 },
  root: { flex: 1 },
  title: { fontSize: 20, fontWeight: "800", lineHeight: 26 },
});
