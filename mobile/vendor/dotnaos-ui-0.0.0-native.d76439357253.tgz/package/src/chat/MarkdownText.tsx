import type { ReactNode } from "react";
import { Platform, StyleSheet, Text, View, type StyleProp, type TextStyle } from "react-native";
import { resolveChatNativeTheme, type ChatNativeTheme } from "./theme";

export interface ChatNativeMarkdownTextProps { style?: StyleProp<TextStyle>; text: string; theme?: ChatNativeTheme; }

export function ChatNativeMarkdownText({ style, text, theme }: ChatNativeMarkdownTextProps) {
  const colors = resolveChatNativeTheme(theme);
  return <View style={styles.root}>{String(text || "").split(/```/g).map((part, index) => {
    const key = `${index}-${part.slice(0, 12)}`;
    if (index % 2 === 1) {
      const code = part.replace(/^[a-zA-Z0-9_-]+\n/, "").trim();
      return <View key={key} style={[styles.codeBlock, { backgroundColor: colors.soft }]}><Text style={[styles.codeText, { color: colors.text }]}>{code}</Text></View>;
    }
    return <MarkdownLines key={key} style={style} text={part} theme={theme} />;
  })}</View>;
}

function MarkdownLines({ style, text, theme }: ChatNativeMarkdownTextProps) {
  const colors = resolveChatNativeTheme(theme);
  return <View style={styles.lines}>{String(text || "").split(/\n/).map((line, index) => {
    const trimmed = line.trim();
    const key = `${index}-${trimmed.slice(0, 10)}`;
    if (!trimmed) return <View key={key} style={styles.spacer} />;
    const heading = trimmed.match(/^(#{1,3})\s+(.+)$/);
    if (heading) {
      const headingStyle = styles[`h${heading[1].length}` as "h1" | "h2" | "h3"];
      return <Text key={key} style={[styles.text, { color: colors.text }, style, headingStyle]}>{renderInlineMarkdown(heading[2], colors)}</Text>;
    }
    const bullet = trimmed.match(/^[-*]\s+(.+)$/);
    if (bullet) return <View key={key} style={styles.listRow}><Text style={[styles.text, styles.bullet, { color: colors.text }, style]}>-</Text><Text style={[styles.text, styles.listText, { color: colors.text }, style]}>{renderInlineMarkdown(bullet[1], colors)}</Text></View>;
    const numbered = trimmed.match(/^(\d+)[.)]\s+(.+)$/);
    if (numbered) return <View key={key} style={styles.listRow}><Text style={[styles.text, styles.bullet, { color: colors.text }, style]}>{numbered[1]}.</Text><Text style={[styles.text, styles.listText, { color: colors.text }, style]}>{renderInlineMarkdown(numbered[2], colors)}</Text></View>;
    return <Text key={key} style={[styles.text, styles.paragraph, { color: colors.text }, style]}>{renderInlineMarkdown(trimmed, colors)}</Text>;
  })}</View>;
}

function renderInlineMarkdown(text: string, colors: ReturnType<typeof resolveChatNativeTheme>): ReactNode[] {
  return String(text || "").split(/(`[^`]+`|\*\*[^*]+\*\*|\\\([^)]+\\\)|\$[^$\n]+\$)/g).filter(Boolean).map((segment, index) => {
    if (segment.startsWith("`") && segment.endsWith("`")) return <Text key={`${index}-code`} style={[styles.inlineCode, { backgroundColor: colors.soft, color: colors.text }]}>{segment.slice(1, -1)}</Text>;
    if (segment.startsWith("**") && segment.endsWith("**")) return <Text key={`${index}-bold`} style={styles.bold}>{segment.slice(2, -2)}</Text>;
    if (segment.startsWith("\\(") && segment.endsWith("\\)")) return <Text key={`${index}-math`} style={[styles.inlineCode, { color: colors.text }]}>{segment.slice(2, -2)}</Text>;
    if (segment.startsWith("$") && segment.endsWith("$")) return <Text key={`${index}-math`} style={[styles.inlineCode, { color: colors.text }]}>{segment.slice(1, -1)}</Text>;
    return segment;
  });
}

const styles = StyleSheet.create({
  bold: { fontWeight: "800" }, bullet: { textAlign: "right", width: 22 },
  codeBlock: { borderRadius: 10, marginVertical: 8, padding: 12 },
  codeText: { fontFamily: Platform.select({ android: "monospace", default: "Menlo", ios: "Menlo" }), fontSize: 13, lineHeight: 19 },
  h1: { fontSize: 22, fontWeight: "800", lineHeight: 28, marginBottom: 8 },
  h2: { fontSize: 19, fontWeight: "800", lineHeight: 25, marginBottom: 7 },
  h3: { fontSize: 17, fontWeight: "800", lineHeight: 23, marginBottom: 6 },
  inlineCode: { borderRadius: 6, fontFamily: Platform.select({ android: "monospace", default: "Menlo", ios: "Menlo" }), paddingHorizontal: 4 },
  lines: { gap: 0 }, listRow: { alignItems: "flex-start", flexDirection: "row", gap: 8, marginBottom: 6 },
  listText: { flex: 1 }, paragraph: { marginBottom: 7 }, root: { gap: 0 }, spacer: { height: 7 }, text: { fontSize: 15, lineHeight: 21 },
});
