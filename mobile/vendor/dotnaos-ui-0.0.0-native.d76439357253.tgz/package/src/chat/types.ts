export type NativeChatRole = "assistant" | "runtime" | "system" | "tool" | "user";
export type NativeChatRunState = "error" | "idle" | "streaming" | "waiting";
export type NativeChatMessageStatus = "completed" | "error" | "pending" | "streaming";

export interface NativeChatAction {
  active?: boolean;
  disabled?: boolean;
  id: string;
  label: string;
  meta?: string;
}

export interface NativeChatAttachment {
  id?: string;
  kind?: string;
  name: string;
  sizeLabel?: string;
}

export interface NativeChatMarkdownBlock {
  content: string;
  id?: string;
  type: "markdown";
}

export interface NativeChatMessage {
  attachments?: readonly NativeChatAttachment[];
  blocks?: readonly NativeChatMarkdownBlock[];
  content: string;
  createdAt?: Date | number | string;
  id: string;
  label?: string;
  role: NativeChatRole;
  status?: NativeChatMessageStatus;
  toolName?: string;
}

export interface NativeChatSuggestion {
  id: string;
  label: string;
  prompt?: string;
}

export interface NativeChatProps {
  branchLabel?: string;
  description?: string;
  disabled?: boolean;
  inputValue: string;
  messages: readonly NativeChatMessage[];
  modelLabel?: string;
  modelOptions?: readonly NativeChatAction[];
  onAttachmentSelect?: () => void;
  onInputChange: (value: string) => void;
  onModelSelect?: (action: NativeChatAction) => void;
  onPermissionSelect?: (action: NativeChatAction) => void;
  onStop?: () => void;
  onSubmit: (value: string) => void;
  onSuggestionSelect?: (suggestion: NativeChatSuggestion) => void;
  permissionLabel?: string;
  permissionOptions?: readonly NativeChatAction[];
  placeholder?: string;
  state?: NativeChatRunState;
  stopLabel?: string;
  submitLabel?: string;
  suggestions?: readonly NativeChatSuggestion[];
  title?: string;
}
