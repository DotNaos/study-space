import { defineComponentDesign } from "../_design/define-design";
import { ChatNativeMessageList } from "./MessageList";
import { nativeChatMessages } from "./_design/fixtures";

export default defineComponentDesign(ChatNativeMessageList, {
  defaults: { messages: nativeChatMessages },
  designs: { default: {}, empty: { messages: [] }, single: { messages: [nativeChatMessages[1]!] } },
  render: (props) => <ChatNativeMessageList {...props} />,
});
