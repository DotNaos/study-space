import { defineComponentDesign } from "../_design/define-design";
import { ChatNativeMessageBubble } from "./MessageBubble";
import { nativeChatMessages } from "./_design/fixtures";

export default defineComponentDesign(ChatNativeMessageBubble, {
  defaults: { message: nativeChatMessages[1]! },
  designs: { default: {}, grouped: { previousRole: "assistant" }, user: { message: nativeChatMessages[0]! } },
  render: (props) => <ChatNativeMessageBubble {...props} />,
});
