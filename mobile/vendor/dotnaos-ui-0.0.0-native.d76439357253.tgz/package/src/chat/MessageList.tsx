import { ScrollView, StyleSheet, type StyleProp, type ViewStyle } from "react-native";
import { ChatNativeMessageBubble } from "./MessageBubble";
import { resolveChatNativeTheme, type ChatNativeTheme } from "./theme";
import type { NativeChatMessage } from "./types";

export interface ChatNativeMessageListProps {
  contentContainerStyle?: StyleProp<ViewStyle>;
  messages: readonly NativeChatMessage[];
  style?: StyleProp<ViewStyle>;
  theme?: ChatNativeTheme;
}

export function ChatNativeMessageList({ contentContainerStyle, messages, style, theme }: ChatNativeMessageListProps) {
  const colors = resolveChatNativeTheme(theme);
  return (
    <ScrollView contentContainerStyle={[styles.body, contentContainerStyle]} showsVerticalScrollIndicator={false} style={[styles.scroll, { backgroundColor: colors.background }, style]}>
      {messages.map((message, index) => <ChatNativeMessageBubble key={message.id} message={message} previousRole={messages[index - 1]?.role} theme={theme} />)}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  body: { gap: 14, paddingBottom: 18, paddingHorizontal: 18, paddingTop: 18 },
  scroll: { flex: 1 },
});
