import { defineComponentDesign } from "../_design/define-design";
import { Chat } from "./Chat";
import { nativeChatMessages, nativeChatSuggestions, noopInputChange, noopSubmit } from "./_design/fixtures";

export default defineComponentDesign(Chat, {
  defaults: { inputValue: "", messages: nativeChatMessages, onInputChange: noopInputChange, onSubmit: noopSubmit, suggestions: nativeChatSuggestions, title: "Assistant" },
  designs: { default: {}, empty: { messages: [] }, streaming: { state: "streaming" } },
  render: (props) => <Chat {...props} />,
});
