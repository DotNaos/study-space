import { defineComponentDesign } from "../_design/define-design";
import { Input } from "./Input";

export default defineComponentDesign(Input, {
  defaults: { placeholder: "Search", value: "" },
  designs: { default: {}, filled: { value: "Study Space" }, disabled: { editable: false, value: "Unavailable" } },
  render: (props) => <Input {...props} />,
});
