import { designTokens } from "@dotnaos/design";
import type { ReactNode } from "react";
import { Pressable, StyleSheet, View, type PressableProps, type StyleProp, type ViewStyle } from "react-native";
import { useNativeTheme } from "../theme";
import { Text } from "./Text";

export interface ListItemProps extends Omit<PressableProps, "children" | "style"> {
  leading?: ReactNode;
  subtitle?: string;
  title: string;
  trailing?: ReactNode;
  divider?: boolean;
  variant?: "plain" | "card";
  titleNumberOfLines?: number;
  subtitleNumberOfLines?: number;
  style?: StyleProp<ViewStyle>;
}

/** A content-sized row. Plain rows are separated by a hairline, not individual cards. */
export function ListItem({ disabled = false, leading, subtitle, title, trailing, divider = true, variant = "plain", titleNumberOfLines = 2, subtitleNumberOfLines = 1, style, ...props }: ListItemProps) {
  const { colors } = useNativeTheme();
  return (
    <Pressable
      accessibilityRole={props.onPress ? "button" : undefined}
      accessibilityState={disabled ? { disabled: true } : undefined}
      {...props}
      disabled={disabled || !props.onPress}
      style={({ pressed }) => [
        {
          minHeight: 56,
          paddingVertical: designTokens.spacing[2],
          borderBottomWidth: divider ? StyleSheet.hairlineWidth : 0,
          borderColor: colors.border,
          backgroundColor: pressed ? colors.surfaceMuted : "transparent",
          opacity: disabled && props.onPress ? 0.5 : 1,
        },
        variant === "card" && { paddingHorizontal: designTokens.spacing[3], borderWidth: 1, borderRadius: designTokens.radii[3], backgroundColor: colors.surface },
        style,
      ]}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: designTokens.spacing[3] }}>
        {leading ? <View style={{ flexShrink: 0 }}>{leading}</View> : null}
        <View style={{ flex: 1, minWidth: 0, gap: designTokens.spacing[1] }}>
          <Text numberOfLines={titleNumberOfLines} size="l" style={{ fontWeight: "500", lineHeight: 22 }} text={title} />
          {subtitle ? <Text color="muted" numberOfLines={subtitleNumberOfLines} size="s" style={{ lineHeight: 17 }} text={subtitle} /> : null}
        </View>
        {trailing ? <View style={{ flexShrink: 0 }}>{trailing}</View> : null}
      </View>
    </Pressable>
  );
}
