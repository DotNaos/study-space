import { defineComponentDesign } from "../_design/define-design";
import { NativeContainer } from "./NativeContainer";
import { Text } from "./Text";

export default defineComponentDesign(NativeContainer, {
  defaults: { children: <Text text="Native container" />, padding: 3, radius: 3, surface: "content" },
  designs: { default: {}, panel: { surface: "panel" }, raised: { surface: "raised" } },
  render: (props) => <NativeContainer {...props} />,
});
