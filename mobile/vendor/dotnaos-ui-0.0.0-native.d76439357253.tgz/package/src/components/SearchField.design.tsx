import { defineComponentDesign } from "../_design/define-design";
import { SearchField } from "./SearchField";

export default defineComponentDesign(SearchField, { defaults: { value: "", onValueChange: () => {}, placeholder: "Search courses" }, designs: { default: {}, filled: { value: "Biology" } }, render: (props) => <SearchField {...props} /> });
