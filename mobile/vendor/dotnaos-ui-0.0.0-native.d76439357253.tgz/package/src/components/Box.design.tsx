import { defineComponentDesign } from "../_design/define-design";
import { Box } from "./Box";
import { Text } from "./Text";

export default defineComponentDesign(Box, { defaults: { children: <Text text="Box content" />, padding: 3, surface: "sunken" }, designs: { default: {} }, render: (props) => <Box {...props} /> });
