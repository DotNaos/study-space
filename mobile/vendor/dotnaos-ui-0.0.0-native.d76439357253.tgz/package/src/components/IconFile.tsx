import { View } from "react-native";
import { useNativeTheme } from "../theme";
import { fileKind, type FileKind } from "./file-kind";
import { iconCatalog, type IconName } from "./icon-catalog";
import { Text } from "./Text";

export interface IconFileProps {
  filename: string;
  mimeType?: string | null;
  size?: number;
  appearance?: "color" | "monochrome";
}
const symbols: Record<FileKind, IconName> = { pdf: "file-text", image: "file-image", spreadsheet: "file-spreadsheet", document: "file-text", presentation: "presentation", archive: "file-archive", audio: "file-audio", video: "file-video", code: "file-code", file: "file" };
const labels: Record<FileKind, string> = { pdf: "PDF", image: "Bild", spreadsheet: "Tabelle", document: "Dokument", presentation: "Präsentation", archive: "Archiv", audio: "Audio", video: "Video", code: "Code", file: "Datei" };

/** The file identity stays behind the same Icon.File contract as the web library. */
export function IconFile({ filename, mimeType, size = 28, appearance = "color" }: IconFileProps) {
  const { colors } = useNativeTheme();
  const kind = fileKind(filename, mimeType);
  const Symbol = iconCatalog[symbols[kind]];
  const color = appearance === "monochrome" ? colors.textMuted : kind === "pdf" ? colors.danger : kind === "image" ? colors.success : colors.accent;
  return (
    <View accessible accessibilityRole="image" accessibilityLabel={labels[kind]} style={{ width: size, height: size, flexShrink: 0 }}>
      <Symbol size={size} color={color} strokeWidth={1.7} />
      {kind === "pdf" ? <View style={{ position: "absolute", bottom: -2, left: -1, right: -1, alignItems: "center", backgroundColor: colors.background }}><Text text="PDF" allowFontScaling={false} style={{ color, fontSize: 8, lineHeight: 10, fontWeight: "700" }} /></View> : null}
    </View>
  );
}
