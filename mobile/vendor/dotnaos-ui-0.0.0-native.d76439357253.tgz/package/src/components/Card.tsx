import type { NativeContainerProps } from "./NativeContainer";
import { NativeContainer } from "./NativeContainer";

export interface CardProps extends Omit<NativeContainerProps, "surface"> {}

export function Card({ padding = 3, radius = 4, ...props }: CardProps) {
  return <NativeContainer {...props} padding={padding} radius={radius} surface="raised" />;
}
