import { defineComponentDesign } from "../_design/define-design";
import { Icon } from "./Icon";

export default defineComponentDesign(Icon, { defaults: { name: "search" }, designs: { default: {}, navigation: { name: "chevron-right" }, missingImage: { name: "image-off" } }, render: (props) => <Icon {...props} /> });
