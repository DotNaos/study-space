import { designTokens, designTokenThemes } from "@dotnaos/design";
import { Pressable, type PressableProps, type StyleProp, type ViewStyle } from "react-native";
import { useNativeTheme } from "../theme";
import { Text } from "./Text";

export type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "danger";
export type ButtonSize = "sm" | "md" | "lg";
const buttonHeights = { sm: 36, md: 44, lg: 52 } as const;

export interface ButtonProps extends Omit<PressableProps, "children" | "style"> {
  disabled?: boolean;
  label: string;
  size?: ButtonSize;
  style?: StyleProp<ViewStyle>;
  variant?: ButtonVariant;
}

export function Button({ disabled = false, label, size = "md", style, variant = "primary", ...props }: ButtonProps) {
  const { colors } = useNativeTheme();
  // Published token versions before accentSolid use the light accent for solid controls.
  const solidAccent = "accentSolid" in colors && typeof colors.accentSolid === "string"
    ? colors.accentSolid : designTokenThemes.light.colors.accent;
  const variantStyles: Record<ButtonVariant, ViewStyle> = {
    primary: { backgroundColor: solidAccent, borderColor: solidAccent },
    secondary: { backgroundColor: colors.surfaceMuted, borderColor: colors.border },
    outline: { backgroundColor: "transparent", borderColor: colors.border },
    ghost: { backgroundColor: "transparent", borderColor: "transparent" },
    danger: { backgroundColor: colors.danger, borderColor: colors.danger },
  };
  return (
    <Pressable accessibilityRole="button" {...props} disabled={disabled} style={({ pressed }) => [{ alignItems: "center", borderRadius: designTokens.radii[4], borderCurve: "continuous", borderWidth: 1, justifyContent: "center", minHeight: buttonHeights[size], opacity: disabled ? 0.5 : pressed ? 0.85 : 1, paddingHorizontal: designTokens.spacing[3], paddingVertical: designTokens.spacing[2] }, variantStyles[variant], style]}>
      <Text color={variant === "primary" || variant === "danger" ? "inverted" : "text"} style={{ fontWeight: "600" }} text={label} />
    </Pressable>
  );
}
