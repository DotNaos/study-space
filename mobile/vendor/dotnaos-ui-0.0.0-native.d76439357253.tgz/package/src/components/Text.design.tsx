import { defineComponentDesign } from "../_design/define-design";
import { Text } from "./Text";

export default defineComponentDesign(Text, { defaults: { text: "Native text" }, designs: { default: {}, muted: { color: "muted" }, mono: { mono: true } }, render: (props) => <Text {...props} /> });
