import { designTokens, type SizeIndex } from "@dotnaos/design";
import type { ReactNode } from "react";
import type { StyleProp, ViewProps, ViewStyle } from "react-native";
import { NativeContainer } from "./NativeContainer";

export type StackDirection = "vertical" | "horizontal";
export type StackAlign = "start" | "center" | "end" | "stretch";
export type StackJustify = "start" | "center" | "end" | "between" | "around";
const alignItems = { start: "flex-start", center: "center", end: "flex-end", stretch: "stretch" } as const;
const justifyContent = { start: "flex-start", center: "center", end: "flex-end", between: "space-between", around: "space-around" } as const;

export interface StackProps extends Omit<ViewProps, "children" | "style"> {
  align?: StackAlign;
  children?: ReactNode;
  direction?: StackDirection;
  gap?: SizeIndex;
  justify?: StackJustify;
  style?: StyleProp<ViewStyle>;
}

export function Stack({ align = "stretch", children, direction = "vertical", gap = 2, justify = "start", style, ...props }: StackProps) {
  return <NativeContainer {...props} style={[{ alignItems: alignItems[align], flexDirection: direction === "vertical" ? "column" : "row", gap: designTokens.spacing[gap], justifyContent: justifyContent[justify] }, style]}>{children}</NativeContainer>;
}
