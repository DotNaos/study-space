import { defineComponentDesign } from "../_design/define-design";
import { Card } from "./Card";
import { Text } from "./Text";

export default defineComponentDesign(Card, { defaults: { children: <Text text="Card content" /> }, designs: { default: {}, compact: { padding: 2 } }, render: (props) => <Card {...props} /> });
