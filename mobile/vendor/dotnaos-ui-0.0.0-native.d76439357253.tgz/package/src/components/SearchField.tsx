import { designTokens } from "@dotnaos/design";
import { Pressable, View, type TextInputProps } from "react-native";
import { useNativeTheme } from "../theme";
import { Icon } from "./Icon";
import { Input } from "./Input";

export interface SearchFieldProps extends Omit<TextInputProps, "value" | "onChangeText" | "style"> {
  value: string;
  onValueChange: (value: string) => void;
  clearLabel?: string;
}
export function SearchField({ value, onValueChange, clearLabel = "Clear search", ...props }: SearchFieldProps) {
  const { colors } = useNativeTheme();
  return <View style={{ flexDirection: "row", alignItems: "center", minHeight: 48, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceMuted, borderRadius: designTokens.radii[3], paddingLeft: designTokens.spacing[3], gap: designTokens.spacing[2] }}>
    <Icon name="search" color="muted" />
    <Input accessibilityRole="search" autoCapitalize="none" autoCorrect={false} returnKeyType="search" {...props} value={value} onChangeText={onValueChange} style={{ flex: 1, minWidth: 0, borderWidth: 0, backgroundColor: "transparent", paddingHorizontal: 0 }} />
    {value ? <Pressable accessibilityRole="button" accessibilityLabel={clearLabel} onPress={() => onValueChange("")} style={{ width: 44, minHeight: 44, alignItems: "center", justifyContent: "center" }}><Icon name="close" color="muted" size={18} /></Pressable> : <View style={{ width: designTokens.spacing[3] }} />}
  </View>;
}
