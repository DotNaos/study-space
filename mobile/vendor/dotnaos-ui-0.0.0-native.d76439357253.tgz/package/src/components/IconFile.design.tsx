import { defineComponentDesign } from "../_design/define-design";
import { IconFile } from "./IconFile";

export default defineComponentDesign(IconFile, { defaults: { filename: "Syllabus.pdf" }, designs: { default: {}, image: { filename: "figure.png" }, table: { filename: "measurements.csv" }, archive: { filename: "materials.zip" } }, render: (props) => <IconFile {...props} /> });
