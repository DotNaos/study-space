import { View, type AccessibilityProps } from "react-native";
import { useNativeTheme } from "../theme";
import { IconFile } from "./IconFile";
import { iconCatalog, type IconName } from "./icon-catalog";

export interface IconProps extends AccessibilityProps {
  name: IconName;
  size?: number;
  color?: "text" | "muted" | "accent" | "danger";
}
function IconRoot({ name, size = 20, color = "text", ...props }: IconProps) {
  const { colors } = useNativeTheme();
  const Symbol = iconCatalog[name];
  return <View accessible={Boolean(props.accessibilityLabel)} {...props} style={{ width: size, height: size }}><Symbol size={size} color={color === "muted" ? colors.textMuted : colors[color]} strokeWidth={1.8} /></View>;
}
export const Icon = Object.assign(IconRoot, { File: IconFile });
export type { IconName } from "./icon-catalog";
export type { IconFileProps } from "./IconFile";
