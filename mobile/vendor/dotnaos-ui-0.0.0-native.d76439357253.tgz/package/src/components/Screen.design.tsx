import { SafeAreaProvider } from "react-native-safe-area-context";
import { defineComponentDesign } from "../_design/define-design";
import { Screen } from "./Screen";
import { SearchField } from "./SearchField";
import { Text } from "./Text";
export default defineComponentDesign(Screen, {
  defaults: { children: <Text text="Scroll content" />, footer: <SearchField value="" onValueChange={() => {}} placeholder="Search courses" /> },
  designs: { default: {}, noFooter: { footer: undefined } },
  render: (props) => <SafeAreaProvider initialMetrics={{ frame: { x: 0, y: 0, width: 390, height: 844 }, insets: { top: 47, right: 0, bottom: 34, left: 0 } }}><Screen {...props} /></SafeAreaProvider>,
});
