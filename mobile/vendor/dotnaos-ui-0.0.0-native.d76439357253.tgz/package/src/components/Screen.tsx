import { designTokens } from "@dotnaos/design";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Keyboard, KeyboardAvoidingView, Platform, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNativeTheme } from "../theme";

export interface ScreenProps { children: ReactNode; footer?: ReactNode; }
/** The footer occupies layout space: no overlay hides the final row or keyboard input. */
export function Screen({ children, footer }: ScreenProps) {
  const { colors } = useNativeTheme();
  const insets = useSafeAreaInsets();
  const frame = useRef<View>(null);
  const [top, setTop] = useState(0);
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  useEffect(() => {
    const show = Keyboard.addListener("keyboardDidShow", () => setKeyboardVisible(true));
    const hide = Keyboard.addListener("keyboardDidHide", () => setKeyboardVisible(false));
    return () => { show.remove(); hide.remove(); };
  }, []);
  return <View ref={frame} onLayout={() => frame.current?.measureInWindow((_x, y) => setTop(y))} style={{ flex: 1, backgroundColor: colors.background }}>
    <KeyboardAvoidingView enabled={Boolean(footer)} behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={top} style={{ flex: 1 }}>
      <View style={{ flex: 1 }}>{children}</View>
      {footer ? <View testID="screen-footer" style={{ borderTopWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: designTokens.spacing[4], paddingTop: designTokens.spacing[2], paddingBottom: Math.max(keyboardVisible ? 0 : insets.bottom, designTokens.spacing[2]), backgroundColor: colors.background }}>{footer}</View> : null}
    </KeyboardAvoidingView>
  </View>;
}
