import { ArrowLeft, BookOpen, Check, ChevronDown, ChevronRight, ClipboardList, ExternalLink, File, FileArchive, FileAudio, FileCode2, FileImage, FileSpreadsheet, FileText, FileVideo, Folder, ImageOff, Link, MessageSquare, Presentation, Search, X } from "lucide-react-native";

export const iconCatalog = {
  "arrow-left": ArrowLeft,
  "book-open": BookOpen,
  check: Check,
  "chevron-down": ChevronDown,
  "chevron-right": ChevronRight,
  "clipboard-list": ClipboardList,
  close: X,
  "external-link": ExternalLink,
  file: File,
  "file-archive": FileArchive,
  "file-audio": FileAudio,
  "file-code": FileCode2,
  "file-image": FileImage,
  "file-spreadsheet": FileSpreadsheet,
  "file-text": FileText,
  "file-video": FileVideo,
  folder: Folder,
  "image-off": ImageOff,
  link: Link,
  message: MessageSquare,
  presentation: Presentation,
  search: Search,
} as const;
export type IconName = keyof typeof iconCatalog;
