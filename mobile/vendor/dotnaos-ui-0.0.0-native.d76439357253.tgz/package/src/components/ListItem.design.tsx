import { defineComponentDesign } from "../_design/define-design";
import { ListItem } from "./ListItem";

export default defineComponentDesign(ListItem, { defaults: { title: "Course material", subtitle: "Syllabus.pdf · 218 KB" }, designs: { default: {}, card: { variant: "card" }, longTitle: { title: "A long material title that wraps naturally without covering its metadata or changing the icon column", titleNumberOfLines: 0 }, disabled: { disabled: true, onPress: () => {} } }, render: (props) => <ListItem {...props} /> });
