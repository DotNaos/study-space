export type FileKind = "pdf" | "image" | "spreadsheet" | "document" | "presentation" | "archive" | "audio" | "video" | "code" | "file";

/** Prefer an explicit MIME type; generic binary MIME types fall back to the filename. */
export function fileKind(filename: string, mimeType?: string | null): FileKind {
  const mime = mimeType?.split(";")[0].trim().toLowerCase() ?? "";
  if (mime === "application/pdf") return "pdf";
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("audio/")) return "audio";
  if (mime.startsWith("video/")) return "video";
  if (/spreadsheet|excel|csv/.test(mime)) return "spreadsheet";
  if (/presentation|powerpoint/.test(mime)) return "presentation";
  if (/word|opendocument.text/.test(mime)) return "document";
  if (/zip|compressed|gzip|x-tar|archive/.test(mime)) return "archive";
  const extension = filename.split(/[?#]/, 1)[0].split(".").pop()?.toLowerCase();
  if (extension === "pdf") return "pdf";
  if (/^(png|jpe?g|gif|webp|svg|heic|avif|bmp|tiff?)$/.test(extension ?? "")) return "image";
  if (/^(csv|tsv|xlsx?|ods)$/.test(extension ?? "")) return "spreadsheet";
  if (/^(docx?|odt|rtf|txt|md)$/.test(extension ?? "")) return "document";
  if (/^(pptx?|odp|key)$/.test(extension ?? "")) return "presentation";
  if (/^(zip|rar|7z|tar|gz|bz2|xz)$/.test(extension ?? "")) return "archive";
  if (/^(mp3|wav|m4a|aac|flac|ogg)$/.test(extension ?? "")) return "audio";
  if (/^(mp4|mov|webm|mkv|avi)$/.test(extension ?? "")) return "video";
  if (/^(py|ipynb|js|ts|tsx|jsx|json|html|css|cpp|c|rs|go|sql|r|sh)$/.test(extension ?? "")) return "code";
  if (mime.startsWith("text/")) return "document";
  return "file";
}
