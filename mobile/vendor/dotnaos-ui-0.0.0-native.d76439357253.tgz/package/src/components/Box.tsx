import type { NativeContainerProps } from "./NativeContainer";
import { NativeContainer } from "./NativeContainer";

export type BoxProps = NativeContainerProps;

export function Box(props: BoxProps) {
  return <NativeContainer {...props} />;
}
