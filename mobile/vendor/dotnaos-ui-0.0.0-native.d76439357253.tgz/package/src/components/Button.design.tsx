import { defineComponentDesign } from "../_design/define-design";
import { Button } from "./Button";

export default defineComponentDesign(Button, { defaults: { label: "Continue" }, designs: { default: {}, secondary: { variant: "secondary" }, disabled: { disabled: true } }, render: (props) => <Button {...props} /> });
