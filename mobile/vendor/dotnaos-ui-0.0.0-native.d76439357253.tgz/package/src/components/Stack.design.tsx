import { defineComponentDesign } from "../_design/define-design";
import { Stack } from "./Stack";
import { Text } from "./Text";

export default defineComponentDesign(Stack, { defaults: { children: <><Text text="First" /><Text text="Second" /></>, gap: 2 }, designs: { default: {}, horizontal: { direction: "horizontal" } }, render: (props) => <Stack {...props} /> });
