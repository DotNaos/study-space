import { designTokens, type SizeIndex } from "@dotnaos/design";
import type { ReactNode } from "react";
import { View, type StyleProp, type ViewProps, type ViewStyle } from "react-native";
import { useNativeTheme } from "../theme";

export type NativeContainerSurface = "transparent" | "content" | "panel" | "raised" | "sunken" | "overlay" | "control";

export interface NativeContainerProps extends Omit<ViewProps, "children" | "style"> {
  children?: ReactNode;
  padding?: SizeIndex;
  radius?: keyof typeof designTokens.radii;
  style?: StyleProp<ViewStyle>;
  surface?: NativeContainerSurface;
}

export function NativeContainer({ children, padding, radius, style, surface = "transparent", ...props }: NativeContainerProps) {
  const { colors } = useNativeTheme();
  const surfaceStyle: ViewStyle = surface === "transparent" ? {}
    : surface === "content" ? { backgroundColor: colors.background }
      : surface === "sunken" || surface === "control" ? { backgroundColor: colors.surfaceMuted, borderColor: colors.border, borderWidth: surface === "control" ? 1 : 0 }
        : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: surface === "overlay" ? 0 : 1 };

  return (
    <View
      {...props}
      style={[
        surfaceStyle,
        padding === undefined ? null : { padding: designTokens.spacing[padding] },
        radius === undefined ? null : { borderRadius: designTokens.radii[radius], borderCurve: "continuous" },
        style,
      ]}
    >
      {children}
    </View>
  );
}
