import { designTokens } from "@dotnaos/design";
import { View } from "react-native";
import { Text } from "./Text";

export interface SectionHeaderProps { title: string; subtitle?: string; }
export function SectionHeader({ title, subtitle }: SectionHeaderProps) {
  return <View style={{ paddingTop: designTokens.spacing[4], paddingBottom: designTokens.spacing[2], gap: designTokens.spacing[1] }}>
    <Text accessibilityRole="header" selectable text={title} size="l" style={{ fontWeight: "600", lineHeight: 22 }} />
    {subtitle ? <Text selectable color="muted" text={subtitle} /> : null}
  </View>;
}
