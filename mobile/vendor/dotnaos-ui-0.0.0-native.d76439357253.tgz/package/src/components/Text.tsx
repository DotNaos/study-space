import { designTokens } from "@dotnaos/design";
import { Text as NativeText, type StyleProp, type TextProps as NativeTextProps, type TextStyle } from "react-native";
import { useNativeTheme } from "../theme";

export type TextSize = "s" | "m" | "l";
export type TextColor = "text" | "inverted" | "muted" | "accent" | "danger" | "warning" | "success";
const textSizes = { s: designTokens.typography.textS, m: designTokens.typography.textM, l: designTokens.typography.textL } as const;

export interface TextProps extends Omit<NativeTextProps, "children"> {
  color?: TextColor;
  mono?: boolean;
  size?: TextSize;
  style?: StyleProp<TextStyle>;
  text: string;
}

export function Text({ color = "text", mono = false, size = "m", style, text, ...props }: TextProps) {
  const { colors } = useNativeTheme();
  const textColors = { text: colors.text, inverted: colors.textInverted, muted: colors.textMuted, accent: colors.accent, danger: colors.danger, warning: colors.warning, success: colors.success } as const;
  return <NativeText {...props} style={[{ color: textColors[color], fontFamily: mono ? "monospace" : undefined, fontSize: textSizes[size], lineHeight: textSizes[size] * designTokens.typography.leadingNormal }, style]}>{text}</NativeText>;
}
