import { defineComponentDesign } from "../_design/define-design";
import { SectionHeader } from "./SectionHeader";

export default defineComponentDesign(SectionHeader, { defaults: { title: "Herbstsemester 2026" }, designs: { default: {}, longTitle: { title: "Grundlagen Biologie und Daten, Sequenz-Alignment und Phylogenetik" }, description: { subtitle: "Lecture notes and exercises" } }, render: (props) => <SectionHeader {...props} /> });
