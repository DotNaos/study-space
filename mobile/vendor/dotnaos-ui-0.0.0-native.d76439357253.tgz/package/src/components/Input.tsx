import { designTokens } from "@dotnaos/design";
import { TextInput, type StyleProp, type TextInputProps, type TextStyle } from "react-native";
import { useNativeTheme } from "../theme";

export interface InputProps extends Omit<TextInputProps, "style"> {
  style?: StyleProp<TextStyle>;
}

export function Input({ placeholderTextColor, style, ...props }: InputProps) {
  const { colors } = useNativeTheme();
  return (
    <TextInput
      {...props}
      placeholderTextColor={placeholderTextColor ?? colors.textMuted}
      style={[
        {
          minHeight: 44,
          borderRadius: designTokens.radii[3],
          borderCurve: "continuous",
          borderColor: colors.border,
          borderWidth: 1,
          backgroundColor: colors.surfaceMuted,
          color: colors.text,
          fontSize: designTokens.typography.textL,
          paddingHorizontal: designTokens.spacing[3],
          paddingVertical: designTokens.spacing[2],
        },
        style,
      ]}
    />
  );
}
