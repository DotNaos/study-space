import { type ComponentType, type ReactNode } from "react";

export interface ComponentDesignDefinition<Props extends object = Record<string, unknown>> {
  component: ComponentType<Props>;
  defaults: Readonly<Props>;
  initialCase: string;
  isStateful: false;
  cases: Readonly<Record<string, Readonly<Partial<Props>>>>;
  render: (props: Readonly<Props>) => ReactNode;
}

export function defineComponentDesign<Props extends object>(
  component: ComponentType<Props>,
  options: {
    defaults: Readonly<Props>;
    designs: Readonly<Record<string, Readonly<Partial<Props>>>> & { default: Readonly<Partial<Props>> };
    render: (props: Readonly<Props>) => ReactNode;
  },
): ComponentDesignDefinition<Props> {
  return { component, defaults: options.defaults, initialCase: "default", isStateful: false, cases: options.designs, render: options.render };
}
