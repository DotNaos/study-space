import { designTokenThemes } from "@dotnaos/design";
import { createContext, useContext, type ReactNode } from "react";
import { useColorScheme } from "react-native";

export type NativeThemeMode = "light" | "dark" | "system";
export type NativeTheme = {
  mode: "light" | "dark";
  colors: (typeof designTokenThemes)["light"]["colors"] | (typeof designTokenThemes)["dark"]["colors"];
};

const themes: Record<"light" | "dark", NativeTheme> = {
  light: { mode: "light", colors: designTokenThemes.light.colors },
  dark: { mode: "dark", colors: designTokenThemes.dark.colors },
};

const NativeThemeContext = createContext<NativeTheme | null>(null);

export function NativeThemeProvider({ children, mode = "system" }: { children: ReactNode; mode?: NativeThemeMode }) {
  const systemMode = useColorScheme() === "dark" ? "dark" : "light";
  const resolvedMode = mode === "system" ? systemMode : mode;
  return <NativeThemeContext.Provider value={themes[resolvedMode]}>{children}</NativeThemeContext.Provider>;
}

export function useNativeTheme(): NativeTheme {
  const inherited = useContext(NativeThemeContext);
  const systemMode = useColorScheme() === "dark" ? "dark" : "light";
  return inherited ?? themes[systemMode];
}
