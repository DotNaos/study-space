import { defineComponentDesign } from "./_design/define-design";
import { Text } from "./components/Text";
import { NativeThemeProvider } from "./theme";

export default defineComponentDesign(NativeThemeProvider, {
  defaults: { children: <Text text="Native theme" />, mode: "system" },
  designs: { default: {}, light: { mode: "light" }, dark: { mode: "dark" } },
  render: (props) => <NativeThemeProvider {...props} />,
});
