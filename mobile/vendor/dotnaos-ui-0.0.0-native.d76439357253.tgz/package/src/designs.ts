import screen from "./components/Screen.design";
import sectionHeader from "./components/SectionHeader.design";
import searchField from "./components/SearchField.design";
import iconFile from "./components/IconFile.design";
import icon from "./components/Icon.design";
import box from "./components/Box.design";
import button from "./components/Button.design";
import card from "./components/Card.design";
import nativeContainer from "./components/NativeContainer.design";
import input from "./components/Input.design";
import listItem from "./components/ListItem.design";
import stack from "./components/Stack.design";
import text from "./components/Text.design";
import chat from "./chat/Chat.design";
import composer from "./chat/Composer.design";
import markdownText from "./chat/MarkdownText.design";
import messageBubble from "./chat/MessageBubble.design";
import messageList from "./chat/MessageList.design";
import nativeThemeProvider from "./theme.design";
import type { ComponentDesignDefinition } from "./_design/define-design";

export interface PackagedComponentDesign { name: string; source: string; designSource: string; definition: ComponentDesignDefinition<any>; }
export const componentDesignStyles = Object.freeze([]);
export const componentDesigns: readonly PackagedComponentDesign[] = Object.freeze([
  design("NativeThemeProvider", "src/theme.tsx", nativeThemeProvider),
  design("NativeContainer", "src/components/NativeContainer.tsx", nativeContainer),
  design("Input", "src/components/Input.tsx", input),
  design("ListItem", "src/components/ListItem.tsx", listItem),
  design("Icon", "src/components/Icon.tsx", icon),
  design("IconFile", "src/components/IconFile.tsx", iconFile),
  design("SearchField", "src/components/SearchField.tsx", searchField),
  design("SectionHeader", "src/components/SectionHeader.tsx", sectionHeader),
  design("Screen", "src/components/Screen.tsx", screen),
  design("Box", "src/components/Box.tsx", box),
  design("Button", "src/components/Button.tsx", button),
  design("Card", "src/components/Card.tsx", card),
  design("Stack", "src/components/Stack.tsx", stack),
  design("Text", "src/components/Text.tsx", text),
  design("Chat", "src/chat/Chat.tsx", chat),
  design("ChatNativeComposer", "src/chat/Composer.tsx", composer),
  design("ChatNativeMarkdownText", "src/chat/MarkdownText.tsx", markdownText),
  design("ChatNativeMessageBubble", "src/chat/MessageBubble.tsx", messageBubble),
  design("ChatNativeMessageList", "src/chat/MessageList.tsx", messageList),
]);

function design<Props extends object>(name: string, source: string, definition: ComponentDesignDefinition<Props>): PackagedComponentDesign {
  return { name, source, designSource: source.replace(/\.tsx$/, ".design.tsx"), definition };
}
